from manim import *
import numpy as np
import tensorflow as tf

class NeuralNetwork(Scene):
    def construct(self):
        # Create the first column of circles with text labels
        column1 = VGroup(*[
            VGroup(Circle(radius=0.5, color=BLUE, stroke_width=3), Text(f"Circle {i+1}"))
            for i in range(3)
        ])
        column1.arrange(DOWN, buff=1, aligned_edge=LEFT)
        column1.set(width=column1[0].get_width())

        # Create the second column of circles with a text label
        column2 = VGroup(
            VGroup(Circle(radius=1, color=RED, stroke_width=5, fill_opacity=0.5), Text("Circle 4"))
        )
        column2.arrange(DOWN, buff=1, aligned_edge=LEFT)
        column2.set(width=column2[0].get_width())

        # Create arrow connecting circle 1 to circle 4
        arrow = Arrow(column1[0].get_right(), column2[0].get_left(), color=YELLOW)

        # Position the columns and arrow
        columns = VGroup(column1, column2, arrow)
        columns.arrange(RIGHT, buff=1)
        columns.move_to(ORIGIN)
        self.play(Create(columns))

#https://github.com/3b1b/videos/blob/master/_2017/nn/part1.py