from manim import *
import numpy as np
import tensorflow as tf

class NeuralNetwork(Scene):
    def construct(self):
        # Create the input layer
        input_layer = self.create_layer(2, "Input Layer")

        # Create the hidden layer
        hidden_layer = self.create_layer(4, "Hidden Layer")

        # Create the output layer
        output_layer = self.create_layer(1, "Output Layer")

        # Connect the layers
        self.connect_layers(input_layer, hidden_layer)
        self.connect_layers(hidden_layer, output_layer)

        # Add the layers to the scene
        self.play(*[Create(layer) for layer in [input_layer, hidden_layer, output_layer]])

        # Generate random data
        x_train = np.random.rand(100, 2)
        y_train = np.random.rand(100, 1)

        # Define the model architecture
        model = tf.keras.Sequential([
            tf.keras.layers.Dense(4, activation='relu', input_shape=(2,)),
            tf.keras.layers.Dense(1, activation='sigmoid')
        ])

        # Compile the model
        model.compile(optimizer='adam',
                      loss='binary_crossentropy',
                      metrics=['accuracy'])

        # Train the model
        for i in range(10):
            # Forward pass
            with tf.GradientTape() as tape:
                y_pred = model(x_train)
                loss = tf.keras.losses.binary_crossentropy(y_train, y_pred)

            # Backward pass
            grads = tape.gradient(loss, model.trainable_weights)
            model.optimizer.apply_gradients(zip(grads, model.trainable_weights))

            # Update the weights and biases of the neural network
            for layer in [hidden_layer, output_layer]:
                for neuron in layer[0]:
                    for i, weight in enumerate(neuron.weights):
                        weight_label = neuron.weight_labels[i]
                        self.play(ReplacementTransform(weight_label, Text(f"{weight.numpy():.2f}")))
                    bias_label = neuron.bias_label
                    self.play(ReplacementTransform(bias_label, Text(f"{neuron.bias.numpy():.2f}")))

            # Animate the loss function
            self.animate_loss(loss.numpy())

            # Animate the prediction process
            self.animate_prediction(model, input_layer, output_layer)

    def create_layer(self, num_neurons, name):
        # Create the neurons
        neurons = VGroup(*[Neuron() for _ in range(num_neurons)])
        neurons.arrange(DOWN)

        # Create the name label
        name_label = Text(name)

        # Create the layer
        layer = VGroup(neurons, name_label)
        layer.arrange(RIGHT)

        return layer

    def connect_layers(self, layer1, layer2):
        # Connect each neuron in layer1 to each neuron in layer2
        for neuron1 in layer1[0]:
            for neuron2 in layer2[0]:
                self.play(Create(Line(neuron1, neuron2)))

    def animate_loss(self, loss):
        # Create the loss graph
        graph = Axes(
            x_range=[0, len(loss)],
            y_range=[0, max(loss)],
            x_length=8,
            y_length=6,
            axis_config={"include_tip": False},
            x_axis_config={"numbers_to_include": range(0, len(loss), 2)},
            y_axis_config={"numbers_to_include": range(0, int(max(loss))+1, 2)},
        )
        graph.to_edge(RIGHT)

        # Create the loss curve
        curve = VMobject()
        curve.set_points_smoothly([graph.c2p(i, l) for i, l in enumerate(loss)])
        curve.set_color(RED)

        # Add the loss graph to the scene
        self.play(Create(graph))

        # Animate the loss curve
        self.play(Create(curve))

        # Update the loss curve after each epoch
        for i in range(1, len(loss)):
            new_curve = VMobject()
            new_curve.set_points_smoothly([graph.c2p(j, l) for j, l in enumerate(loss[:i+1])])
            new_curve.set_color(RED)
            self.play(Transform(curve, new_curve))

    def animate_prediction(self, model, input_layer, output_layer):
        # Generate random input data
        x_test = np.random.rand(1, 2)

        # Predict the output data
        y_pred = model(x_test)

        # Animate the input data
        input_data = VGroup(*[Dot() for _ in range(2)])
        input_data.arrange(RIGHT)
        input_data.move_to(input_layer)
        input_data[0].move_to(input_layer[0][0])
        input_data[1].move_to(input_layer[0][1])
        self.play(Create(input_data))

        # Animate the output data
        output_data = Dot()
        output_data.move_to(output_layer[0][0])
        self.play(Create(output_data))

        # Animate the prediction process
        for i, neuron in enumerate(output_layer[0]):
            z = tf.reduce_sum(tf.multiply(x_test, neuron.weights)) + neuron.bias
            a = tf.sigmoid(z)
            self.play(ReplacementTransform(output_data, Dot().move_to(neuron)))
            self.play(ReplacementTransform(input_data, Dot().move_to(input_layer)))
            self.play(ReplacementTransform(Dot().move_to(input_layer[0][i]), Dot().move_to(neuron)))
            self.play(ReplacementTransform(Dot().move_to(neuron), output_data))

    class Neuron(Circle):
        def __init__(self, **kwargs):
            super().__init__(radius=0.5, **kwargs)
            self.bias = tf.Variable(tf.random.normal((1,)))
            self.bias_label = Text(f"{self.bias.numpy():.2f}").next_to(self, RIGHT)
            self.add(self.bias_label)
            self.weights = [tf.Variable(tf.random.normal((1,))) for _ in range(2)]
            self.weight_labels = [Text(f"{weight.numpy():.2f}").next_to(self, LEFT) for weight in self.weights]
            self.add(*self.weight_labels)

        def activate(self, x):
            z = tf.reduce_sum(tf.multiply(x, self.weights)) + self.bias
            return tf.sigmoid(z)