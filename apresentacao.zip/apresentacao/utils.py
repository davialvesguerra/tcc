import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix
from tabulate import tabulate
import json
import shap

def plot_predicted_probabilities(y_test: np.array, y_pred_prob: np.array):
    # Get the predicted probabilities for each class
    bom_pagador = y_pred_prob[y_test == 0]
    mau_pagador = y_pred_prob[y_test == 1]

    # Create the boxplot
    fig, ax = plt.subplots(figsize=(5, 3))
    bp = ax.boxplot([bom_pagador, mau_pagador])
    ax.set_xticklabels(['Bom pagador', 'Mau pagador'])
    plt.show()

def model_evaluation(y_pred,y_test, nome_modelo, to_latex = False, dir_save = "../relatorio/imagens/resultados"):

    # Confusion Matrix
    cm = confusion_matrix(y_test,y_pred)
    names = ['Verdadeiro Negativo','Falso Positivo','Falso Negativo','Verdadeiro Positivo']
    counts = [value for value in cm.flatten()]
    percentages = ['{0:.2%}'.format(value) for value in cm.flatten()/np.sum(cm)]
    labels = [f'{v1}\n{v2}\n{v3}' for v1, v2, v3 in zip(names,counts,percentages)]
    labels = np.asarray(labels).reshape(2,2)
    sns.heatmap(cm,annot = labels,cmap = 'Blues',fmt ='')

    plt.xlabel('Valores preditos')
    plt.ylabel('Valores reais')

    # Save the plot as an image
    plt.savefig(dir_save+"/"+nome_modelo+'.png')

    # Classification Report
    print(classification_report(y_test,y_pred))

    if(to_latex):
      report = classification_report(y_test,y_pred, output_dict=True)
      report_df = pd.DataFrame(report).transpose()

      # Convert the DataFrame to LaTeX
      latex_output = tabulate(report_df, tablefmt="latex", headers="keys")

      # Print the LaTeX output
      print(latex_output)

def export_shap_values(shap_values, name: str, directory: str = './shap/',):
  json_shap = {
    '.values': shap_values.values.tolist(),
    '.base_values': shap_values.base_values.tolist(),
    '.feature_names': shap_values.data.columns.to_list(),
    '.feature_values': shap_values.data.to_numpy().tolist()
  }

  # Save the dictionary to a JSON file
  with open(directory+name, 'w') as f:
      json.dump(json_shap, f)

def load_shap_values(path_file: str):
  with open(path_file, 'r') as f:
    json_shap = json.load(f)

  shap_explanations = []
  n_obs = len(json_shap['.values'])

  for i in range(n_obs):
    shap_explanations.append(
      shap.Explanation(
        values=np.squeeze(json_shap['.values'][i]),
        base_values=json_shap['.base_values'][i][0],
        data=json_shap['.feature_values'][i],
        feature_names=json_shap['.feature_names']
        )
    )

  shap_value = shap.Explanation(
    values=np.stack([exp.values for exp in shap_explanations]),
    base_values=np.stack([exp.base_values for exp in shap_explanations]),
    data= np.stack([exp.data for exp in shap_explanations]),
    feature_names=json_shap['.feature_names']
    )

  return shap_value

def join_shap_values(name_file: str, list_path_file: [str], directory: str='./shap/'):

  values = []
  base_values = []
  feature_values = []
  
  for path_file in list_path_file:
    with open(directory+path_file, 'r') as f:
      json_shap = json.load(f)

      values.append(np.squeeze(json_shap['.values']))
      base_values.append(json_shap['.base_values'])
      feature_values.append(json_shap['.feature_values'])

  feature_names = json_shap['.feature_names']
  values = np.array(values)
  base_values = np.array(base_values)
  feature_values = np.array(feature_values)

  json_shap = {
    '.values': values.reshape(-1, values.shape[-1]).tolist(),
    '.base_values': base_values.reshape(-1, base_values.shape[-1]).tolist(),
    '.feature_names': feature_names,
    '.feature_values': feature_values.reshape(-1, feature_values.shape[-1]).tolist()
  }

    # Save the dictionary to a JSON file
  with open(directory+name_file, 'w') as f:
      json.dump(json_shap, f)

